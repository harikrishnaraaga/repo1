import React from 'react';
//import logo from './logo.svg';
//import './App.css';
import Calcilogic from './Components/CalLogic';
import Incr from './Components/IncChnClr';
//import EmpView from './Components/EmpView';
import EmpDetails from './Components/Emp1';
import TickedClock from './Components/Clock';

import Changes from './Components/FiveClrCompA';
import BookingForm from './Components/HotelRoom';


function App() {
  return (
    <div className="App">
      <BookingForm />
    </div>
  );
}

export default App;
