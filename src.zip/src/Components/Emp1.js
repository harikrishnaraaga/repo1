import React from "react";
import EmpTable from "./EmpView";

class EmpDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employee: [
        { name: "Honey", id: "123", position: "SEngineer" },
        { name: "Chinnu", id: "234", position: "JEngineer" },
        { name: "Kittu", id: "345", position: "DesignAnalyst" }
      ]
    };
  }
  render() {
    return <EmpTable employee={this.state.employee} />;
  }
}
export default EmpDetails;
