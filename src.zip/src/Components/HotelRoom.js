import React from 'react';
//import './Home.css';
export default class BookingForm extends React.Component{
constructor(props){
    super(props);
    this.state = {firstname:"",
                    lastname:"",
                    address: "",
                    persons:0,
                    service: "",
                    country:""
                    };
    this.upperCase = this.upperCase.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.submit = this.submit.bind(this);
}

upperCase(event){
    this.setState({[event.target.name]:event.target.value.toUpperCase()});
}

handleChange(event){
    this.setState({[event.target.name]:event.target.value});
    console.log(this.state);
}

submit(event){
    alert('Thank You! Name:' + this.state.firstname + this.state.lastname +
'Number of persons:' + this.state.persons +'Food service:' + this.state.service +
'Country:' + this.state.country);
event.preventDefault();
}
resset = () => {
    this.setState({
        firstname: "",
        lastname:"",
    });
}
render(){
    return(
        <div class="Form-section">
        <form onSubmit={this.submit}>
        <h1>Book Now!</h1>
        <label>FirstName:</label>
        <input type="text" placeholder="First Name" name="firstname"
            value={this.state.firstname} onChange={this.upperCase}/><br/><br/>
        <label>LastName:</label>
        <input type="text" placeholder="Last Name" name="lastname" value={this.state.lastname}
        onChange={this.upperCase}/><br/><br/>
        <label>Address:</label>
        <textarea placeholder="Address" name="address" onChange={this.handleChange}>
        </textarea>
        <br/><br/>
        <label>Number of persons</label>
        <input type="number" name="persons" min="1" onChange={this.handleChange}/><br/><br/>
        <label>Want Food service?</label>
        <input type="checkbox" name="service" onChange={this.handleChange}/><br/><br/>
        <label>Which Country you want?</label>
        <select name="country" onChange={this.handleChange}>
            <option>Select Country</option>
            <option>India</option>
            <option>Paris</option>
            <option>London</option>
            <option>New York</option>
            <option>England</option>
        </select><br/><br/>
        <input type="submit"/>
        <input type="reset" value="reset" onClick={this.resset} />
        </form>
    </div>
);
}
}