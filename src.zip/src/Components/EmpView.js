import React from "react";

class EmpTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = { emp: this.props.employee };
  }
  render() {
    return (
      <div>
        <table>
          <tr>
            <th>Employee name</th>
            <th>Employee id</th>
            <th>Position</th>
          </tr>
          {this.state.emp.map((Emp, i) => (
            <tr>
              <td>{Emp.name}</td>
              <td>{Emp.id}</td>
              <td>{Emp.position}</td>
            </tr>
          ))}
        </table>
      </div>
    );
  }
}
export default EmpTable;
