import React from "react";

export default class Calci extends React.Component {
  render() {
    return (
      <div>
        <input
          type="text" name="num1" placeholder="firstNum"
          value={this.props.num1}
          onChange={this.props.handleChange}/>
        <input type="text" name="num2" placeholder="secondNum" value={this.props.num2}
          onChange={this.props.handleChange}/>
      </div>
    );
  }
}
//export default Calci;
