import React from "react";

class Textfields extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <input type="text" onChange={this.props.handleChange} />
      </div>
    );
  }
}
export default Textfields;
