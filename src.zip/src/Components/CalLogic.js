import React from "react";
import Calci from "./Cal";

export default class Calcilogic extends React.Component {
  constructor(props) {
    super(props);
    this.state = { num1: "", num2: "", result: "" };
    this.handleChange = this.handleChange.bind(this);
    this.add = this.add.bind(this);
  }
  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }
  add() {
    this.setState({
      result: parseInt(this.state.num1) + parseInt(this.state.num2),
      num1: "",
      num2: ""
    });
  }
  render() {
    return (
      <div>
        <Calci
          handleChange={this.handleChange}
          num1={this.state.num1}
          num2={this.state.num2}
        />
        <button onClick={this.add}>Add</button>
        <p>{this.state.result}</p>
      </div>
    );
  }
}

