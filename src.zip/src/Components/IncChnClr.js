import React from "react";

export default class Incr extends React.Component {
  constructor(props) {
    super(props);
    this.state = { num: 0, bgr: "" };
    this.inc = this.inc.bind(this);
  }
  inc() {
    this.setState({
      num: this.state.num + 1,
      bgr: this.state.num % 2 === 0 ? "green" : "red"
    });
  }
  render() {
    let font_color = { color: this.state.bgr };
    return (
      <div style={font_color}>
        <p>The current value : {this.state.num} </p>
        <button onClick={this.inc}>Increae</button>
      </div>
    );
  }
}

