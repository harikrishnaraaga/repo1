import React from "react";
import Textfields from "./FiveClrCompB"

class Changes extends React.Component {
  constructor(props) {
    super(props);
    this.state = { Color: "" };
    this.handleChange = this.handleChange.bind(this);
    this.changeClr = this.changeClr.bind(this);
  }
  handleChange(event) {
    this.state.Color = event.target.value;
  }
  changeClr() {
    this.setState({ Color: this.state.Color });
  }
  render() {
    let h1_style = { color: this.state.Color };
    return (
      <div>
        <Textfields handleChange={this.handleChange} />
        <h1 style={h1_style}>ReactJS Session</h1>
        <button onClick={this.changeClr}>Change color</button>
      </div>
    );
  }
}
export default Changes;
