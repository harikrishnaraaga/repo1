class Demo
  { 
   public static void main(String ar[])
    {
    int total=0;
  for(int i=0;i<ar.length;i++)
{
     int a = Integer.parseInt(ar[0]);
     int b = Integer.parseInt(ar[1]);
     int c = a+b;
     System.out.println(c);
}
    }
  }