import java.io.*;
class StringPract
{
	public static void main(String... args) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the string to test :");
		s1 = br.readLine();
		StringBuffer sb = new StringBuffer();
		sb.reverse();
		if(sb==s1)
		{
			System.out.println("the string that you entered is palindrome ");
		}
		else
		{
			System.out.println("It is not palindrome");
		}
	}
}