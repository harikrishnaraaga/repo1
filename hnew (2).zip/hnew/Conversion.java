import java.util.*;
class Conversion
{
	public static void main(String args[])
	{
	Scanner src=new Scanner(System.in);
	System.out.println("Enter your choice");
	System.out.println("1.Fahrenheit to celsius");
	System.out.println("2.Celsius to fahrenheit");
	int choice=src.nextInt();
	switch(choice)
	{
	case 1 : 
		System.out.println("Enter Fahrenheit number");
		double fa=src.nextDouble();
		double c=(fa-32)*5/9;
		
		System.out.println("celsius is "+String.format("%.2f",c));
		break;
	case 2:
		System.out.println("Enter Celsius number");
		double ce=src.nextDouble();
		double f=(ce*9/5)+32;
		System.out.println("celsius is "+ f);
		break;
	default : 	
		System.out.println("please enter some number");
	}
}
}