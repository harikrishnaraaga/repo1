class Triangle4
{
static int a;
static int b;
static int h;

Triangle4(int a,int b,int h)
{
 this.a=a;
this.b=b;
this.h=h;
}
void area()
{
	int area=(b*h)/2;
	System.out.println("area of traingle is :"+area);
}
void peri()
{
	int peri=a+b+h;
	System.out.println("perimeter of traingle is :"+peri);
}
	
public static void main(String... args)
	{
	Triangle4 t4=new Triangle4(3,4,5);
	t4.area();
	t4.peri();
	}
}