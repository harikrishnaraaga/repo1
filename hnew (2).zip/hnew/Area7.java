import java.util.Scanner;

public class Area7 {
	static int length;
	static int breadth;
	Area7(int length,int breadth)
	{
	this.length=length;
	this.breadth=breadth;	
	}
	void returnArea()
	{
		int area=length*breadth;
		System.out.println("area of rectangle :"+area);
	}
	public static void main(String[] args) {
		
		Scanner src = new Scanner(System.in);
		System.out.println("Enter length :");
		int length=src.nextInt();
		System.out.println("Enter breadth :");
		int breadth = src.nextInt();
		Area7 a = new Area7(length,breadth);
		a.returnArea();
	}
}