import java.util.*;
class EmpObjCount
{
	static int count=1;
public static void main(String... args)
{
	Scanner src = new Scanner(System.in);
	EmpObjCount E1=null;
	while(true){
		System.out.println("Do you want create emp object\n1.yes 2.no");
		int choice=src.nextInt();
		if(choice==1)
		{
		E1= new EmpObjCount();
		count++;
		}
		else
		{
		System.out.println("total employee objects are :"+count);
		break;
		}
	
		}
}
}
		