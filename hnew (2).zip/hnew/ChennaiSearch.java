class ChennaiSearch
{
	static int count;
	static int index;
	public static void main(String... args)
	{
	String st1 = "hai this is chennai and chennai and living in chennai";
	while(st1.length()>0)
	{
	index=st1.indexOf("chennai");
	
	if(index!=-1)
		{
		System.out.println(index);
		index=index++;
		}
		else
		{
		break;
		}
	}
}
}