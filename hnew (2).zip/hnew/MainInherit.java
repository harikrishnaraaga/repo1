class Person
{
	Integer id;
	String address;
	Person()
	{
		
	}
	Person(Integer id,String address)
	{
		this.id=id;
		this.address=address;
	}
	void display()
	{
		System.out.println("Id is :"+id);
		System.out.println("Address is :"+address);
	}
	
}
class Employee extends Person
{
	Integer empId;
	String companyName;
	Employee(Integer empId,String companyName,Integer id,String address)
	{
	super(id,address);
	this.empId=empId;
	this.companyName=companyName;
	}
	void display()
	{
	super.display();	
	System.out.println("empId is :"+empId);
	System.out.println("companyName is :"+companyName);
	}
}
public class MainInherit
{
	public static void main(String... args)
	{	
	Person p = new Person(132,"Chennai");
	Employee e = new Employee(234,"Csscorp",23,"Bangalore");
	p.display();
	e.display();
	}
}







