import java.util.*;
abstract class Shape
{
	abstract void area();
}
class Square extends Shape
{
	int side;
	
	Square(int side)
	{
		this.side=side;
	}
	
	void area()
	{
	System.out.println("area of square is :"+side*side);
	}
}
class Circle extends Shape
{
	int radius;
	
	Circle(int radius)
	{
	this.radius=radius;
	}
	
	void area()
	{
	System.out.println("area of the circle is :"+3.14*radius);
	}
}
public class MainShape
{
	
	public static void main(String... args){
	Shape s1;
	Scanner src = new Scanner(System.in);
	System.out.println("please select an option\n1.square 2.circle");
	int ch=src.nextInt();
	if(ch==1)
	{
		System.out.println("please enter side");
		int side=src.nextInt();
		s1=new Square(side);
		s1.area();
	}
	else if(ch==2)
	{
		System.out.println("please enter radius");
		int radius=src.nextInt();
		s1=new Circle(radius);
		s1.area();
	}
	else
	{
		System.out.println("please select any of the above option");
	}
}
}
