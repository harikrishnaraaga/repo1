/*abstract class Shape
{
	abstract void RectangleArea();
	abstract void SquareArea();	
	abstract void CircleArea();
}*/
class Rectangle
{
	void RectangleArea()
	{
	Integer length=5;
	Integer breadth=6;
	int area = length*breadth;
	System.out.println("area of rectangle is :"+area);
	}
}
class Square
{
	void SquareArea()
	{
	Integer side=7;
	int area=side*side;
	System.out.println("area of square is :"+area);
	}
}
class Circle
{
	void CircleArea()
	{
	Integer radius=8;
	Double area = 3.14*radius*radius;
	System.out.println("area of circle is :"+area);
	}
}
class MainShape6Loop
{
	public static void main(String... args) throws Exception
	{
	Rectangle[] rec = new Rectangle[4];
	for(int i =0;i<rec.length;i++)
	{
	rec[i]=new Rectangle();
	rec[i].RectangleArea();
	}
	Square[] sqr = new Square[4];
	for(int j =0;j<sqr.length;j++)
	{
	sqr[j]=new Square();
	sqr[j].SquareArea();
	}
	Circle[] cir = new Circle[5];
	for(int k =0;k<cir.length;k++)
	{
	cir[k]=new Circle();
	cir[k].CircleArea();
	}

	}
}