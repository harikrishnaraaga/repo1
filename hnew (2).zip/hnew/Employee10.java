
import java.util.Scanner;

public class Employee10 {
	public static void main(String[] args) {
		String name1,name2,name3;
		int yoj1,yoj2,yoj3;
		String add1,add2,add3;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name1 :");
		name1 = sc.nextLine();
		System.out.println("Enter Year Of Joining1 :");
		yoj1 = sc.nextInt();
		System.out.println("Address1 :");
		add1 = sc.next();
		System.out.println("Enter name2 :");
		name2 = sc.next();
		System.out.println("Enter Year Of Joining2 :");
		yoj2 = sc.nextInt();
		System.out.println("Address2 :");
		add2 = sc.next();
		System.out.println("Enter name3 :");
		name3 = sc.next();
		System.out.println("Enter Year Of Joining3 :");
		yoj3 = sc.nextInt();
		System.out.println("Address3 :");
		add3 = sc.next();
		sc.close();
		System.out.println("Name\t\tYear of joining\tAddress");
		System.out.println(name1+"\t\t"+yoj1+"\t\t"+add1);
		System.out.println(name2+"\t\t"+yoj2+"\t\t"+add2);
		System.out.println(name3+"\t\t"+yoj3+"\t\t"+add3);
	}
}