class Triangle3
{
int a;
int b;
int h;

void area()
{
	int area=(b*h)/2;
	System.out.println("area of traingle is :"+area);
}
void peri()
{
	int peri=a+b+h;
	System.out.println("perimeter of traingle is :"+peri);
}
public static void main(String... args)
	{
	Triangle3 tr = new Triangle3();
	tr.a=3;
	tr.b=6;
	tr.h=7;
	tr.area();
	tr.peri();
	}
}