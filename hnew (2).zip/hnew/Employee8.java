import java.util.*;
class Employee8
{
	int salary;
	int numberOfHours;
	void getInfo()
	{
		Scanner src = new Scanner(System.in);
		System.out.println("Enter salary :");
		salary=src.nextInt();
		System.out.println("salary is:"+salary);
		System.out.println("Enter Working Hours :");
		numberOfHours=src.nextInt();
		System.out.println("No of working hours :"+numberOfHours);
	}
	void AddSal()
	{
		if(salary<500)
		{
			salary=salary+10;
			System.out.println("salary incr by 10$ :"+salary+"$");
		}
	}
	void AddWork()
	{
		if(numberOfHours>6)
		{
			salary = salary+5;
			System.out.println("salary incr by 5$ "+salary+"$");
		}
	}
	
	public static void main(String... args)
	{
		Employee8 e8 = new Employee8();
		e8.getInfo();
		e8.AddSal();
		e8.AddWork();
		System.out.println(" your total salary is :"+e8.salary+"$");
	}
}




	