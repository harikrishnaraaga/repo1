import java.util.*;
class EmployeeCount
{
	static int count=0;

public static void main(String... args)
{
	Scanner src = new Scanner(System.in);
	//int n = src.nextInt();
	System.out.println("Do you want create emp object\n1.yes 2.no");
	int choice=src.nextInt();

	while(choice==1){
	EmployeeCount[] ec= new EmployeeCount[];
	for(int i = 0;i<ec.length;i++)
	{
	ec[i]=new EmployeeCount();
	count++;
	}
	System.out.println("Employee object created");
	}
	System.out.println("total employee objects are :"+count);
	}
}