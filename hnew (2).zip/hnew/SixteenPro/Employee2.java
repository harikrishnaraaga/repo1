import java.util.*;
class Employee
{
	String empId;
	String empName;
	double salary;

	Employee(String empId,String empName,double salary)
	{
	this.empId=empId;
	this.empName=empName;
	this.salary=salary;
	}

	public String getempId()
	{
	return empId;
	}
	public void setempId(String empId)
	{
	this.empId=empId;
	}
	
	public String getempName()
	{
	return empName;
	}
	public void setempName(String empName)
	{
	this.empName=empName;
	}

	public double getsalary()
	{
	return salary;
	}
	public void setsalary(double salary)
	{
	this.salary=salary;
	}
	void display()
	{
	System.out.println("Emp Id is :"+empId);
	System.out.println("Emp Name is :"+empName);
	System.out.println("Emp salary is :"+salary);
	}
}
class EmpIdComparator implements Comparator<Employee>
	{
		public int compare(Employee o1,Employee o2)
		{
		return o1.empId.compareTo(o2.empId);
		}
	}
	class EmpNameComparator implements Comparator<Employee>
	{
		public int compare(Employee o1,Employee o2)
		{
		return o1.empName.compareTo(o2.empName);
		}
	}
	class EmpSalComparator implements Comparator<Employee>
	{
		public int compare(Employee o1,Employee o2)
		{
			if(o1.salary > o2.salary)
			{
			return 1;
			}
			else if(o1.salary < o2.salary)	
			{
			return -1;
			}
			else
			{ 
			return 0;
			}
		}
	}

public class Employee2
{
public static void main(String... args)
{
	EmpIdComparator eic = new EmpIdComparator();
	SortedSet<Employee> s1 = new TreeSet<Employee>(eic);
	Employee e1 = new Employee("1","Hari",43688423);
	Employee e2 = new Employee("2","Nani",2368423);
	Employee e3 = new Employee("3","Pandu",536884);
	Employee e4 = new Employee("4","Chinnu",836823);
	s1.add(e1);
	s1.add(e2);
	s1.add(e3);
	s1.add(e4);

	for(Employee e : s1)
	{
	e.display();
	}
}
}
