class FourthPro
{
public static void main(String... args)
{
	Scanner src = new Scanner(System.in)
	String s1 = src.next();
	String s2 = src.next();
	String s3= s1.concat(s2)
	System.out.println(s3);
}