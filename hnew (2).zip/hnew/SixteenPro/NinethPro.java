import java.util.*;
class NinethPro
{
	
	public static void main(String... args)
	{
	Scanner src = new Scanner(System.in);
	System.out.println("Enter String1 and String2")
	String s1 = src.next();
	String s2 = src.next();

	boolean b1 = s1.equalsIgnoreCase(s2);
	
	System.out.println(s1 +" equals "+s2+"?"+b1);	
	
	}
}