import java.util.*;

class Employee implements Comparable<Employee>
{
	String empId;
	String empName;
	double salary;

	Employee(String empId,String empName,double salary)
	{
	this.empId=empId;
	this.empName=empName;
	this.salary=salary;
	}

	public String getempId()
	{
	return empId;
	}
	public void setempId(String empId)
	{
	this.empId=empId;
	}
	
	public String getempName()
	{
	return empName;
	}
	public void setempName(String empName)
	{
	this.empName=empName;
	}

	public double getsalary()
	{
	return salary;
	}
	public void setsalary(double salary)
	{
	this.salary=salary;
	}

	public int compareTo(Employee o)
	{
		return this.salary.compareTo(o.salary);
	}

	void display()
	{
	System.out.println("Emp Id is :"+empId);
	System.out.println("Emp Name is :"+empName);
	System.out.println("Emp salary is :"+salary);
	}
	
public static void main(String... args)
{
	SortedSet<Employee> s1 = new TreeSet<Employee>();
	Employee e1 = new Employee("1","Hari",43688423);
	Employee e2 = new Employee("2","Nani",2368423);
	Employee e3 = new Employee("3","Pandu",536884);
	Employee e4 = new Employee("4","Chinnu",836823);
	s1.add(e1);
	s1.add(e2);
	s1.add(e3);
	s1.add(e4);

	for(Employee e : s1)
	{
	e.display();
	}
}
}
