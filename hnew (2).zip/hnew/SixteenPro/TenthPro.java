import java.util.*;

public class TenthPro {
 
  public static void main(String[] args)
    {
       Scanner src = new Scanner(System.in);
        String str = src.next();
        byte[] arr = str.getBytes();
        String byStr = new String(arr);
        System.out.println("This is byte array String " +byStr);
    }
}