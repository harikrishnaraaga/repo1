class EigthPro
{
	public static void main(String... args)
	{
	String s1 = "Stephen Edwin King";
	String s2 = "Walter Winchell";
	String s3 = "Mike Royko";

	boolean b1 = s1.equals(s2);
	boolean b2 = s1.equals(s3);

	System.out.println(s1 +" equals "+s2+"?"+b1);	
	System.out.println(s1+ " equals "+s3+"?"+b2);
	}
}