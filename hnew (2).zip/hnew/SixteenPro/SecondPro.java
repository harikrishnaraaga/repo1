import java.util.*;
class SecondPro
{
public static void main(String... args)
{
	Scanner src = new Scanner(System.in);
	String s1 = src.next();
	String s2 = src.next();

	int i1 = s1.compareToIgnoreCase(s2);
	if(i1==0)
	{
		System.out.println(s1+" equal to "+s2);
	}
	else
	{
	System.out.println("Not equal");
	}
}
}