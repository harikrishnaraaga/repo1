import java.util.*;
class FirstPro
{
public static void main(String... args)
{
	Scanner src = new Scanner(System.in);
	String s1 = "Java Exercises!";
	System.out.println("Enter the position of the character u want :");
	
	int car = src.nextInt();
	int i1 = s1.charAt(car);		
	System.out.println("the character at the given position is :"+(char)i1);
}
}