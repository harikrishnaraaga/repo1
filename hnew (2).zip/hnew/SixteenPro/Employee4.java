import java.util.*;
import java.util.Collections;
class Employee
{
	String empId;
	String empName;
	double salary;

	Employee(String empId,String empName,double salary)
	{
	super();
	this.empId=empId;
	this.empName=empName;
	this.salary=salary;
	}
	Employee()
	{
	}
	public String getempId()
	{
	return empId;
	}
	public void setempId(String empId)
	{
	this.empId=empId;
	}
	
	public String getempName()
	{
	return empName;
	}
	public void setempName(String empName)
	{
	this.empName=empName;
	}

	public double getsalary()
	{
	return salary;
	}
	public void setsalary(double salary)
	{
	this.salary=salary;
	}
	void display()
	{
	System.out.println("Emp Id is :"+empId);
	System.out.println("Emp Name is :"+empName);
	System.out.println("Emp salary is :"+salary);
	}
}
class EmployeeImpl
{
    List<Employee> l1=new ArrayList<Employee>();
    List<Employee> addEmp(Employee e)
    {
        l1.add(e);
        return l1;
    }
}
class EmpIdComparator implements Comparator<Employee>
	{
		public int compare(Employee o1,Employee o2)
		{
		return o1.empId.compareTo(o2.empId);
		}
	}
class EmpNameComparator implements Comparator<Employee>
	{
		public int compare(Employee o1,Employee o2)
		{
		return o1.empName.compareTo(o2.empName);
		}
	}
class EmpSalComparator implements Comparator<Employee>
	{
		public int compare(Employee o1,Employee o2)
		{
			if(o1.salary > o2.salary)
			{
			return 1;
			}
			else if(o1.salary < o2.salary)	
			{
			return -1;
			}
			else
			{ 
			return 0;
			}
		}
	}

public class Employee4
{
public static void main(String... args)
{
	EmployeeImpl el  = new EmployeeImpl();
	Scanner src = new Scanner(System.in);
	do
       	{
                System.out.println("Enter ID name and Salary");
               String id=src.nextInt();
               String name=src.next();
               Double sal=Double.parseDouble(br.readLine());
               Employee e1=new Employee(id,name,sal);
               li=el.addEmp(e1);
            	System.out.println("Do you want to create Employee Object");
	       choice=br.readLine();
	       }while(choice.equals("yes"));

	System.out.println("Enter the sort basis : \n 1.EmpId 2.EmpName 3.Salary");
	int choice1 = src.nextInt();
	List<Employee> s1=  new ArrayList<Employee>();
	Employee e1 = new Employee("1","Hari",4368843);
	Employee e2 = new Employee("2","Nani",2368423);
	Employee e3 = new Employee("3","Pandu",536884);
	Employee e4 = new Employee("4","Chinnu",836823);
	s1.add(e1);
	s1.add(e2);
	s1.add(e3);
	s1.add(e4);
	switch(choice1)
	{
	case 1:	
		System.out.println(" you want to arrange them in 4.Ascending or 5.Descending");
		int choice2 = src.nextInt();
		if(choice2==4)
		{
		Collections.sort(s1, new EmpIdComparator());
		}
		else if(choice2==5)
		{
		Collections.sort(s1, new EmpIdComparator());
		Collections.reverse(s1);
		}
		
		break;
	case 2 :
		System.out.println(" you want to arrange them in 4.Ascending or 5.Descending");
		int choice3 = src.nextInt();
		if(choice3==4)
		{
		Collections.sort(s1, new EmpNameComparator());
		}
		else if(choice3==5)
		{
		Collections.sort(s1, new EmpNameComparator());
		Collections.reverse(s1);
		}
		break;
	case 3 :
		System.out.println(" you want to arrange them in 4.Ascending or 5.Descending");
		int choice4 = src.nextInt();
		if(choice4==4)
		{
		Collections.sort(s1, new EmpSalComparator());
		}
		else if(choice4==5)
		{
		Collections.sort(s1, new EmpSalComparator());
		Collections.reverse(s1);
		}
		break;
	}
	
	
	for(Employee e : s1)
		{
		e.display();
		}
	
}
}
