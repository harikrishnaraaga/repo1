import java.util.*;
class ThirdPro
{
public static void main(String... args)
{
	Scanner src = new Scanner(System.in);
	System.out.println("Enter string 1");
	String s1 = src.next();
	System.out.println("Enter string 2 ");
	String s2 = src.next();
	String s3 = s1.concat(s2);	
	System.out.println(s3);	
}
}