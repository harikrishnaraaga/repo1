public class SixthPro {

    public static void main(String[] args)
    {
        char[] arr = new char[] { '1', '2', '3', '4' };
        String str = String.copyValueOf(arr, 0, 4);

        System.out.println(str);
    }
}