class Teacher
{
	String designation="teaching";
	String college;
	
	void work()
	{
		System.out.println("Teacher is "+designation);
	}
}
class SubjectTeacher extends Teacher
{
	String subName;
	
	SubjectTeacher(String subName)
	{
	this.subName=subName;
	}
	
	void work()
	{
	super.work();
	System.out.println(subName);
	}
}
class TeacherMain
{
	public static void main(String... args)
	{
	SubjectTeacher st=new SubjectTeacher("Physics");
	st.work();
	}
}













