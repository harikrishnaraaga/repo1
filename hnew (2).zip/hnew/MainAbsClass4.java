abstract class AbsClass
{
	AbsClass()
	{
	System.out.println("this is constructor of abstract class");
	}

	abstract void a_method();
	
	void nonAbstract()
	{
	System.out.println("this is normal method of abstract class");
	}
}
class SubClass extends AbsClass
{
	void a_method()
	{
	System.out.println("this is abstract method");
	}
}
class MainAbsClass4
{
	public static void main(String... args)
	{
	SubClass sc = new SubClass();	
	sc.a_method();
	sc.nonAbstract();
	}
}
	