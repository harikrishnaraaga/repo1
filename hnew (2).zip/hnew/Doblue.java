class Doblue
{
	public static void main(String... f)
	{
	double d= 10.5;
	System.out.println(d);
	
	Double d1=new Double(d);
	System.out.println(d1);
	System.out.println(d1 instanceof Double);
	}
}