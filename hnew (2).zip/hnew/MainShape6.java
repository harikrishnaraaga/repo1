abstract class Shape
{
	abstract void RectangleArea();
	abstract void SquareArea();	
	abstract void CircleArea();
}
class Area extends Shape
{
	void RectangleArea()
	{
	Integer length=5;
	Integer breadth=6;
	int area = length*breadth;
	System.out.println("area of rectangle is :"+area);
	}
	void SquareArea()
	{
	Integer side=7;
	int area=side*side;
	System.out.println("area of square is :"+area);
	}
	void CircleArea()
	{
	Integer radius=8;
	Double area = 3.14*radius*radius;
	System.out.println("area of circle is :"+area);
	}
}
class MainShape6
{
	public static void main(String... args) throws Exception
	{
	Area a1 = new Area();
	a1.RectangleArea();
	a1.SquareArea();
	a1.CircleArea();
	}
}