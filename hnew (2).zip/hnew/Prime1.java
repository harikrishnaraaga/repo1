class Prime1
  { 
   public static void main(String ar[])
    {
 int count=0;
  for(int i=0;i<ar.length;i++)
{
int num=Integer.parseInt(ar[i]);
  for(i=2; i<num; i++)
        {
            if(num%i == 0)
            {
                count++;
                break;
            }
        }
        if(count == 0)
        {
            System.out.println("Prime Number");
        }
        else
        {
            System.out.println("Not a Prime Number");
        }
}
    }
  }