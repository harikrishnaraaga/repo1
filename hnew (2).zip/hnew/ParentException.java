import java.io.*;  
class ParentException
{  
  void msg()
	{
	System.out.println("parent");
	}  
}  
  
class TestExceptionChild extends ParentException
{  
  void msg()throws IOException
	{  
    	System.out.println("TestExceptionChild");  
 	 }  
  public static void main(String args[])
{  
   Parent p=new TestExceptionChild();  
   p.msg();  
  }  
}  