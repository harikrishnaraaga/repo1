abstract class Parent
{
	abstract void message();
}
class Parent1 extends Parent
{
	void message()
	{
	System.out.println("this is the first sub class");
	}
}
class Parent2 extends Parent
{
	void message()
	{
	System.out.println("this is the second sub class");
	}
}
class MainParent
{
	public static void main(String... args)
	{
	Parent1 p1=new Parent1();
	p1.message();
	Parent2 p2=new Parent2();
	p2.message();
	}
}