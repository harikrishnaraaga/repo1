import java.io.*;
class InvalidAge extends Exception
{
	InvalidAge(String message)
	{
	super(message);
	}
}
class ChildException
{
	static void ageCheck(int age) throws InvalidAge
	{
		if(age<20)
		{
		throw new InvalidAge("age is lesser");
		}
		else
		{
		System.out.println("welcome");
		}
	}
	
}
class SolveException  extends ChildException
{
	static void ageCheck(int age) throws InvalidAge
	{
		if(age>50)
		{
		throw new InvalidAge("age is bigger");
		}
		else
		{
		System.out.println("welcome");
		}
	}
	
	public static void main(String... args) throws Exception
	{
	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("enter age");
	int age = Integer.valueOf(bf.readLine());
	SolveException ce = new SolveException();
	try
	{
	ce.ageCheck(age);
	}
	catch(InvalidAge e)
	{
	System.out.println(e);
	}
	}
}