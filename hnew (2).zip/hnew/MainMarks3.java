import java.util.*;
abstract class Marks
{
	abstract void getPercentage();
}
class A extends Marks
{
	void getPercentage()
	{
	Scanner src=new Scanner(System.in);
	System.out.println("Enter marks of student A");
	System.out.println("Enter sub1 marks :");
	int sub1=src.nextInt();
	System.out.println("Enter sub2 marks :");
	int sub2=src.nextInt();
	System.out.println("Enter sub3 marks :");
	int sub3=src.nextInt();
	int total=sub1+sub2+sub3;
	System.out.println("total :"+total);
	double div=(double)total/300;
	System.out.println("division :"+div);
	double perc=div*100;
	System.out.println("perc of student A is :"+perc);
	}
}
class B extends Marks
{
	void getPercentage()
	{
	Scanner src=new Scanner(System.in);
	System.out.println("Enter marks of student B");
	System.out.println("Enter sub1 marks :");
	int sub1=src.nextInt();
	System.out.println("Enter sub2 marks :");
	int sub2=src.nextInt();
	System.out.println("Enter sub3 marks :");
	int sub3=src.nextInt();
	System.out.println("Enter sub4 marks :");
	int sub4=src.nextInt();
	Integer total=((sub1+sub2+sub3+sub4)/400)*100;
	double div=(double)total/400;
	double perc=div*100;
	System.out.println("perc of student B is :"+perc);
	}
}
class MainMarks3
{
	public static void main(String... args)
	{
	A s1= new A();
	s1.getPercentage();
	B s2=new B();
	s2.getPercentage();
	}
}