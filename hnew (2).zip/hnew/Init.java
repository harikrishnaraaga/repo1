class Init
{
	public static void main(String args[])
	{
	int i =20;
	System.out.println(i);
	Init1 in = new Init1();
	Integer num = Integer.valueOf(i);
	in.display(num);
	System.out.println("inside main");	
	System.out.println(num instanceof Integer);

	}
}
class Init1
{
	void display(Integer var)
	{
		System.out.println(var);
		System.out.println("inside method");
		System.out.println(var instanceof Integer);
	}
}