import java.util.*;
import java.util.regex.*;
class ExRegec
{
	String mail;
	String pwd;
	String ipadd;
	void email()
	{
	Pattern p = Pattern.compile("[a-zA-Z0-9_]{5,}@[a-z]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})");
	Matcher m = p.matcher(mail);
	boolean b = m.matches();
	System.out.println(b);
	}
	void powd()
	{
	Pattern p = Pattern.compile("");
	Matcher m = p.matcher(pwd);
	boolean b = m.matches();
	System.out.println(b);
	}
	void ipad()
	{
	Pattern p = Pattern.compile("");
	Matcher m = p.matcher(ipadd);
	boolean b = m.matches();
	System.out.println(b);
	}
	public static void main(String... args) throws PatternSyntaxException
	{
	ExRegec er = new ExRegec();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter email :");
	mail = sc.next();
	er.email();
	System.out.println("Enter password :");
	pwd = sc.next();
	er.powd();
	System.out.println("Enter password :");
	ipadd = sc.next();
	er.ipad();
	}
}