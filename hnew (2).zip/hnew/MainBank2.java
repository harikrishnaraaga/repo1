abstract class Bank
{
	abstract void getBalance();
}
class Bank1 extends Bank
{
	void getBalance()
	{
	int balance=100;
	System.out.println("balance in bank1 is :"+balance+"$");
	}
}
class Bank2 extends Bank
{
	void getBalance()
	{
	int balance=150;
	System.out.println("balance in bank2 is :"+balance+"$");
	}
}
class Bank3 extends Bank
{
	void getBalance()
	{
	int balance=200;
	System.out.println("balance in bank3 is :"+balance+"$");
	}
}
public class MainBank2
{
	public static void main(String... args)
	{
	Bank1 b1 = new Bank1();
	b1.getBalance();
	Bank2 b2 = new Bank2();
	b2.getBalance();
	Bank3 b3 = new Bank3();
	b3.getBalance();
	}
}