class PrintNumber
{
	void printn(int n1)
	{
	System.out.println(n1+" is a integer");
	}
	void printn(char n1)
	{
	System.out.println(n1+" is a character");
	}
	void printn(byte n1)
	{
	System.out.println(n1+" is byte");
	}
	void printn(short n1)
	{
	System.out.println(n1+" is short");
	}
	void printn(long n1)
	{
	System.out.println(n1+"this is long");
	}
	void printn(double n1)
	{
	System.out.println(n1+"this is double");
	}
	void printn(float n1)
	{
	System.out.println(n1+"this is float");
	}
	void printn(String n1)
	{
	System.out.println(n1+"this is String");
	}
public static void main(String... args)
{
	int n1 = 23;
	char n2='$';
	byte n3=9;
	short n4=7;
	long n5=242;
	float n6=13.2f;
	String n7="Hai";
	PrintNumber pn = new PrintNumber();
	pn.printn(23);
	pn.printn('$');
	pn.printn(9);
	pn.printn(7);
	pn.printn(32.43);
	pn.printn(242);
	pn.printn(13.2f);
	pn.printn("Hai");
}
}