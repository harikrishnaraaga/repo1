import java.util.Scanner;

public class Area6 {
	int length;
	int breadth;
	void setDim(int length, int breadth)
	{
		this.length=length;
		this.breadth=breadth;
		
	}
	void getArea()
	{
		int area=length*breadth;
		System.out.println("area of rectangle :"+area);
	}
	public static void main(String[] args) {
		Scanner src= new Scanner(System.in);
		System.out.println("Enter length :");
		int length=src.nextInt();
		System.out.println("Enter breadth :");
		int breadth=src.nextInt();
		Area a = new Area();
		a.setDim(length, breadth);
		a.getArea();
	}
}