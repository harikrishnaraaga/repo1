class Second
{
	void samSung(int n,char c)
	{
	System.out.println(""+n+c);
	}
	void samSung(char c,int n)
	{
	System.out.println(c+n);
	}
		public static void main(String... args)
		{
		Second s = new Second();
		s.samSung(23,'c');
		s.samSung('c',23);
		}
}