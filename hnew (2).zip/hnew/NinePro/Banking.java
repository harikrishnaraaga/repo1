class Customer
{
	int custId;
	String custName;
	String custAddress;
	int withdraw;
	void withDraw()
	{
		System.out.println("Enter amount to withdraw :")
		withdraw = 
		if(withdraw>10000)
		{
		System.out.println("you cannot withdraw more than 10000 per day :")
		}
		else
		{
		System.out.println("Amount withdrawn is "+withdraw);
		}
	}
	
}
class Account
{
	
}
class RBI
{
	Customer c = new Customer();
	Account A = new Account();
	double balanceMin;
	double interestMin;
	double withdrawMax;
	public double getInterestRate()
	{
		return 4;
	}
	public double getWithdrawalLimit()
	{
		return 10000;
	}
	public double balanceMin()
	{
		return 1000;
	}
}
class SBI extends RBI
{
	
}
class ICICI extends RBI
{
	
}
class PNB extends RBI
{
	
}
public class Banking {
	
}