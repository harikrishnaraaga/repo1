 $(document).ready(function() {
    $("#img1").draggable();
    $("#bag-img").droppable({
      drop: function( event, ui ) {
        $( this ).addClass( "ui-state-highlight" ).find("p").html( "Dropped!" );
      }
    });
  });