$(document).ready(function() {
$("button").eq(0).click(function() {
	$("div").siblings('.main-column1').eq(1).css({"opacity":"1"});
	 $("button").eq(2).removeAttr("disabled");
	 $("button").eq(3).removeAttr("disabled");
});
});