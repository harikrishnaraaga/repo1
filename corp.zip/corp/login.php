<?php
 include 'connection.php';
   if(!empty($_POST['firstname']) && !empty($_POST['password'])) {  
      $user=$_POST['firstname'];  
      $pass=$_POST['password'];  
      
      mysqli_select_db($conn, 'corp_reg');  
    
      $query=mysqli_query($conn,"SELECT * FROM users WHERE firstname='".$user."' AND password='".$pass."'");  
      $numrows=mysqli_num_rows($query);  
      if($numrows!=0)  
      {  
  		$dbusername='';
  		$dbpassword='';
  	    while($row=mysqli_fetch_assoc($query))  
          {  
            $dbusername=$row['firstname'];  
            $dbpassword=$row['password'];  
          }  
      if($user == $dbusername && $pass == $dbpassword)  
      {  
        session_start();  
        $_SESSION['sess_user']=$user;  
        
        header("refresh:2; url=index.html");
      }  
      } 
  	else {  
  		echo "Invalid username or password!";  
      }  
    } 
    else {  
        echo "All fields are required!";  
    }    
?>