<?php   
  include 'login.php';
  session_start();  
  unset($_SESSION['sess_user']);  
  session_destroy();  
  header("refresh:2; url=index.html");  
?> 