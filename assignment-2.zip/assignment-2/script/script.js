//var box = document.getElementById("cross_button");
var eqId="";
  $(".quest-blocks").click(function() {
	//box.style.visibility="visible";
	eqId=(this.id);
	cross_class = $(".cross_button");
	cross_class.css('display','block');
	$(".output-box").append(cross_class);
	checkQuest();
  });
  $(".cross_button").click(function() {
	  $(".output-box").hide();
  });
  function checkQuest() {
	  if(eqId=="0")
	{
		document.getElementById("quest1").style.visibility="visible";
	}
	else if(eqId=="1")
	{
		document.getElementById("quest2").style.visibility="visible";
	}
	else if(eqId=="2")
	{
		document.getElementById("quest3").style.visibility="visible";
	}
	else if(eqId=="3")
	{
		document.getElementById("quest4").style.visibility="visible";
	}
	else if(eqId=="4")
	{
		document.getElementById("quest5").style.visibility="visible";
	}
	else if(eqId=="5")
	{
		document.getElementById("quest6").style.visibility="visible";
	}
	else if(eqId=="6")
	{
		document.getElementById("quest7").style.visibility="visible";
	}
	else if(eqId=="7")
	{
		document.getElementById("quest8").style.visibility="visible";
	}
	else if(eqId=="8")
	{
		document.getElementById("quest9").style.visibility="visible";
	}
	else 
	{
		document.getElementById("quest10").style.visibility="visible";
	}
  }