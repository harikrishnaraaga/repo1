var box = document.getElementById("output-box");
$(document).ready(function() {
  $(".quest-blocks").click(function() {
	box.style.visibility="visible";
	var eqId = this.id;
	var quest = $("div.questions div:nth-child(1)").val();
	document.getElementById("question-name").innerHTML = quest;
  });
});
  $(".cross").click(function() {
    box.style.visibility="hidden"; 
  });