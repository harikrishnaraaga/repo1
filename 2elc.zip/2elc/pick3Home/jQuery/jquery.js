$(document).ready(function(){
 $("div").siblings('.main-column1').eq(1).css({"opacity":"0.3"});
 $("div").siblings('.main-column1').eq(2).css({"opacity":"0.3"});
 $("button").eq(2).attr("disabled","disabled");
 $("button").eq(3).attr("disabled","disabled");
 $("button").eq(4).attr("disabled","disabled");
 $("button").eq(5).attr("disabled","disabled");
 $("button").eq(0).click(function() {
	$("div").siblings('.main-column1').eq(1).css({"opacity":"1"});
	 $("button").eq(2).removeAttr("disabled");
	 $("button").eq(3).removeAttr("disabled");
});
$("button").eq(1).click(function() {
	$("div").siblings('.main-column1').eq(1).css({"opacity":"1"});
	 $("button").eq(2).removeAttr("disabled");
	 $("button").eq(3).removeAttr("disabled");
});
 $("button").eq(2).click(function() {
	 $("div").siblings('.main-column1').eq(2).css({"opacity":"1"});
	 $("button").eq(4).removeAttr("disabled");
	 $("button").eq(5).removeAttr("disabled");
 });
 $("button").eq(3).click(function() {
	 $("div").siblings('.main-column1').eq(2).css({"opacity":"1"});
	 $("button").eq(4).removeAttr("disabled");
	 $("button").eq(5).removeAttr("disabled");
 });
});
 
 
 