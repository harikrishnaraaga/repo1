var images;
var img=[];
var btn=[];
var x;
var b;

function bagItems(x1) 
{
    images = document.getElementById(x1).getAttribute('src');
            x = document.createElement("IMG");
			x.setAttribute("src", images);
			// x.setAttribute("id", "img-dom");
			x.setAttribute("height", "100");
			x.setAttribute("width", "50");
			x.setAttribute("alt", "image1");
		// document.getElementById("items-nav").appendChild(x);
			// var mbr = document.createElement('br');
			// document.getElementById("items-nav").appendChild(mbr);
		b = document.createElement("BUTTON");
		// b.setAttribute("onclick","removeItems()");
		// b.setAttribute("id","btn-dom")
		b.innerHTML="removebt";
		x.appendChild(b);
		b.setAttribute("onClick", "removeItems(this)");
		document.getElementById("items-nav").appendChild(x);
		
}
function removeItems(item)
 {
	 item.parentElement.removeChild(item.parentElement);
 }
 function disableButton1(){
	document.getElementById("btn2").disabled = true;
	document.getElementById("btn1").disabled = true;
 }
 function disableButton2(){
	document.getElementById("btn1").disabled = true;
	document.getElementById("btn2").disabled = true;
 }
 function disableButton3(){
	document.getElementById("btn4").disabled = true;
	document.getElementById("btn3").disabled = true;
 }
 function disableButton4(){
	document.getElementById("btn3").disabled = true;
	document.getElementById("btn4").disabled = true;
 }
 function disableButton5(){
	document.getElementById("btn6").disabled = true;
	document.getElementById("btn5").disabled = true;
 }
 function disableButton6(){
	document.getElementById("btn5").disabled = true;
	document.getElementById("btn6").disabled = true;
 }
 
 
	 