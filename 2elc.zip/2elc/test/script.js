var dragItem = document.getElementById("dragElement");
alert(dragItem);
var dropLoc = document.getElementById("dragLocation");
alert(dropLoc);
dragItem.ondragstart = function(evt){
	evt.dataTransfer.setData('key', evt.target.id);
	console.log("its dragging....");
}
dropLoc.ondragover = function(evt){
	evt.preventDefault();
	console.log("its dragover....");
}
dropLoc.ondrop = function(evt){
	var dropItem = evt.dataTransfer.getData('key')
	evt.preventDefault();
	console.log("its dropped");
	console.log(dropItem);
	var myElement = document.getElementById(dropItem);
	console.log(myElement);
	var myNewElement = document.createElement('img');
	myNewElement.src = myElement.src;
	dropLoc.appendChild(myNewElement);
}