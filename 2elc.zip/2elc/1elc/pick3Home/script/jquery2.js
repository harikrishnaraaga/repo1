var img;
$(document).ready(function() {
$("button").click(function() {
	img = $(this).siblings().attr('src');
	var displayImg = document.getElementById('items-nav');
	var ndi = document.createElement("DIV");
            x = document.createElement("IMG");
			x.setAttribute("src", img);
			x.setAttribute("height", "100");
			x.setAttribute("width", "50");
			x.setAttribute("alt", "image1");
			ndi.setAttribute("id","div-img");
		b = document.createElement("BUTTON");
		b.setAttribute("id","btn-dom")
		ndi.appendChild(x)
		ndi.appendChild(b);
		b.innerHTML="remove";
		b.setAttribute("onClick", "removeItems(this)");
		displayImg.appendChild(ndi);
	function removeItems(item)
	{
		item.parentElement.parentElement.removeChild(item.parentElement);
	}
});
});