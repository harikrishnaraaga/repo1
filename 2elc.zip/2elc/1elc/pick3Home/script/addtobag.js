var images;
var img=[];
var btn=[];
var x;
var b;

function bagItems(x1) 
{
	var displayImg = document.getElementById('items-nav');
    images = document.getElementById(x1).getAttribute('src');
	// alert(images);
		var ndi = document.createElement("DIV");
            x = document.createElement("IMG");
			x.setAttribute("src", images);
			x.setAttribute("height", "100");
			x.setAttribute("width", "50");
			x.setAttribute("alt", "image1");
			ndi.setAttribute("id","div-img");
		b = document.createElement("BUTTON");
		b.setAttribute("id","btn-dom")
		ndi.appendChild(x)
		ndi.appendChild(b);
		b.innerHTML="remove";
		b.setAttribute("onClick", "removeItems(this)");
		displayImg.appendChild(ndi);
		
}

function removeItems(item)
 {
	 item.parentElement.parentElement.removeChild(item.parentElement);
 }
 function disableButton1(){
	document.getElementById("btn2").disabled = true;
	document.getElementById("btn1").disabled = true;
 }
 function disableButton2(){
	document.getElementById("btn1").disabled = true;
	document.getElementById("btn2").disabled = true;
 }
 function disableButton3(){
	document.getElementById("btn4").disabled = true;
	document.getElementById("btn3").disabled = true;
 }
 function disableButton4(){
	document.getElementById("btn3").disabled = true;
	document.getElementById("btn4").disabled = true;
 }
 function disableButton5(){
	document.getElementById("btn6").disabled = true;
	document.getElementById("btn5").disabled = true;
 }
 function disableButton6(){
	document.getElementById("btn5").disabled = true;
	document.getElementById("btn6").disabled = true;
 }
 
 

	 