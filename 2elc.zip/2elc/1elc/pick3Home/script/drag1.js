
var dragItem = document.getElementById('img1');
alert(dragItem);
var dropLoc = document.getElementById("baggage");
var dropLoc1 = document.getElementById("items-nav");
dragItem.ondragstart = function(evt){
	evt.dataTransfer.setData('key', evt.target.id);
	console.log("its dragging....");
}

dropLoc.ondragover = function(evt){
	evt.preventDefault();
	console.log("its dragover....");
}
dropLoc.ondrop = function(evt){
	var dropItem = evt.dataTransfer.getData('key')
	evt.preventDefault();
	console.log("its dropped");
	console.log(dropItem);
	var myElement = document.getElementById(dropItem);
	console.log(myElement);
	var myNewElement = document.createElement('img');
	myNewElement.src = myElement.src;
	dropLoc1.appendChild(myNewElement);
}