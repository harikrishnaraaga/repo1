var buttonAdd = document.getElementById('btn1');
var buttonRemove = document.getElementById('but2');

var ul = document.getElementById('items-nav');

function bagItems(x) {
var newLi = document.createElement('IMG');
var removeThis = document.createElement('BUTTON');
var textInput = document.getElementById(x).getAttribute('src');
// if(textInput === ""){
  alert('textInput');
// }else{
newLi.value = textInput;
newLi.appendChild(removeThis);
removeThis.innerHTML = "Remove me";
removeThis.onclick = removeMe;
ul.appendChild(newLi);
 // }  
// }

buttonAdd.onclick = function() {
 addLi(); 
};

// buttonRemove.onclick = function() {
 // ul.innerHTML = "";
// };

function removeMe(mouseEvent){
  this.parentNode.remove();
}