import java.io.*;
class Employee
{
 	Integer id;
	String name;
	String dept;
	String doj;
	Double salary;

	void enter() throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emplyee Id ");
		id=Integer.valueOf(br.readLine());
		System.out.println("Enter Name :");
		name=br.readLine();
		System.out.println("Enter dept :");
		dept=br.readLine();
		System.out.println("Enter doj :");
		doj=br.readLine();
		System.out.println("Enter Salary :");
		salary=Double.valueOf(br.readLine());
		storage();
		}
	void display()
		{
		System.out.println("Employee Id :"+id);
		System.out.println("Employee Name :"+name);
		System.out.println("Employee Department :"+dept);
		System.out.println("Employee Joining date :"+doj);
		System.out.println("Employee Salary :"+salary);
		}
	void storage()
		{
		System.out.println("Storage Success!");
		}
}
class MainClass
{
	public static void main(String... args) throws IOException
				{
				BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
				Employee hari=new Employee();
				hari.display();
				hari.enter();
				System.out.println("Details Enter Success!");
				System.out.println("Do you want to display deatils..?\n1.Yes 2.No");
				int choice=Integer.parseInt(br.readLine());
				if(choice==1)
				{
				hari.display();
				}
				else
				{
				System.out.println("Done..!");
				}
				}
}


