class Demo1
  { 
   public static void main(String ar[])
    {
 int total=0;
  for(int i=0;i<ar.length;i++)
{
   total+=Integer.parseInt(ar[i]); 
}
  System.out.println(total);
    }
  }