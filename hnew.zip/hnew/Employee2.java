import java.io.*;
import java.util.*;
class Employee2
{
	Integer id;
	String name;
	String dept;
	String doj;
	Double salary;
	
	public Integer getId()
	{
		return id;
	}
	public void setId(Integer id)
	{
	this.id=id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
	this.name=name;
	}
	public String getDept()
	{
		return dept;
	}
	public void setDept(String dept)
	{
	this.dept=dept;
	}
	public String getDoj()
	{
		return doj;
	}
	public void setDoj(String doj)
	{
	this.doj=doj;
	}
	public Double getSalary()
	{
		return salary;
	}
	public void setSalary(Double salary)
	{
	this.salary=salary;
	}


	Employee2()
	{
	display();
	}

	Employee2(Integer id,String name) throws IOException
	{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter Id :");
	this.id=Integer.parseInt(br.readLine());
	System.out.println("Enter Name :");
	this.name=br.readLine();
	}

	Employee2(Integer id,String name,String dept,String doj,Double salary) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emplyee Id ");
		this.id=Integer.valueOf(br.readLine());
		System.out.println("Enter Name :");
		this.name=br.readLine();
		System.out.println("Enter dept :");
		this.dept=br.readLine();
		System.out.println("Enter doj :");
		this.doj=br.readLine();
		System.out.println("Enter Salary :");
		this.salary=Double.valueOf(br.readLine());
		display();
	}

	void enter() throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Emplyee Id ");
		id=Integer.valueOf(br.readLine());
		System.out.println("Enter Name :");
		name=br.readLine();
		System.out.println("Enter dept :");
		dept=br.readLine();
		System.out.println("Enter doj :");
		doj=br.readLine();
		System.out.println("Enter Salary :");
		salary=Double.valueOf(br.readLine());
		storage();
		}
	void display()
		{
		System.out.println("Employee Id :"+id);
		System.out.println("Employee Name :"+name);
		System.out.println("Employee Department :"+dept);
		System.out.println("Employee Joining date :"+doj);
		System.out.println("Employee Salary :"+salary);
		}
	void storage()
		{
		System.out.println("Storage Success!");
		}
}

class MainClass2
{

	public static void main(String... args) throws IOException
	{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	Employee2 hari=new Employee2();
	System.out.println("Enter your choice");
	System.out.println("1.Invoke Default values ");
	System.out.println("2.Provide only id and name");
	System.out.println("3.Provide all details");
	int choice=Integer.parseInt(br.readLine());
	switch(choice){
	case 1 : 
		Employee2 e=new Employee2();
		break;
	case 2 :
		Employee2 e1=new Employee2(1,"fadf");
		break;
	case 3:
		Employee2 e2=new Employee2(1,"df","asdf","dfda",341.9);
		break;
	default :
		System.out.println("please select an option.");
		}	

	System.out.println("Do you want to change Id\n1.Yes 2.No");
	int ch=Integer.parseInt(br.readLine());
	if(ch==1)
	{
	System.out.println("Enter Id");
	int id=Integer.valueOf(br.readLine());
	hari.setId(id);
	}
	else
	{
	System.out.println("no changes");
	hari.display();
	}
	System.out.println("Do you want to change Name\n1.Yes 2.No");
	int ch1=Integer.parseInt(br.readLine());
	if(ch1==1)
	{
		System.out.println("Enter Name");
	String name=br.readLine();
	hari.setName(name);
	}
	else
	{
	System.out.println("no changes");
	hari.display();
	}
	System.out.println("Do you want to change Dept\n1.Yes 2.No");
	int ch2=Integer.parseInt(br.readLine());
	if(ch2==1)
	{
		System.out.println("Enter Dept");
	String dept=br.readLine();
	hari.setDept(dept);
	}
	else
	{
	System.out.println("no changes");
	hari.display();
	}System.out.println("Do you want to change Doj\n1.Yes 2.No");
	int ch3=Integer.parseInt(br.readLine());
	if(ch3==1)
	{
		System.out.println("Enter Doj");
	String doj=br.readLine();
	hari.setDoj(doj);
	}
	else
	{
	System.out.println("no changes");
	hari.display();
	}System.out.println("Do you want to change salary\n1.Yes 2.No");
	int ch4=Integer.parseInt(br.readLine());
	if(ch4==1)
	{
		System.out.println("Enter salary");
	double salary=Double.valueOf(br.readLine());
	hari.setSalary(salary);
	}
	else
	{
	System.out.println("no changes");
	hari.display();
	}
}
}