import java.io.*;
class BloodBank
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your name");
		String name=br.readLine();
		System.out.println("Hi "+name+" welcome to bloodBank");
		System.out.println("please enter your age to continue");		
		int age=Integer.parseInt(br.readLine());
		if(age<18){
			System.out.println("sorry you cannot donate blood");
			}
		else if(age>=18)
			{
			System.out.println("please enter your bloodGroup");
			String bgr=br.readLine();
			if(bgr=="A"||bgr=="B"||bgr=="O"){
			System.out.println("you can donate your blood");
			}
			else{System.out.println("Sorry you cannot donate blood");}
			}
		else{
			System.out.println("Come back later");}
		}	
}