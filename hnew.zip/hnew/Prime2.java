class Prime2
  { 
   public static void main(String ar[])
    {
  int count=0;
  for(int i=0;i<ar.length;i++)
{
 int maxnum = Integer.parseInt(ar[i]);

        for (int n = 2; n <=maxnum; n++)
        {
	boolean prime=true;
            for (int j=2; j <=n/2; j++)
            {
                if (n%j == 0)
                {
                    prime=false;
                    break;
                }
            }
            if ( prime == true )
                System.out.println(n);
        }
    }
    }
  }