class Hello
{
	public static void main(String a[])
	{

	}
	public static void main(int x[])
	{
	int i=0;
	while(i<x.length){
	System.out.println("sum is "+x[i]);
	i += x[i];
	}
	}
}