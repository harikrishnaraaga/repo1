import java.util.*;
class Numbers
{
public static void main(String[] args)
	{
	Scanner src=new Scanner(System.in);
	System.out.println("Enter the number");
	int num=src.nextInt();
	
	String number = String.valueOf(num);
	for(int i = 0; i < number.length(); i++) 
	{
 	   int j = Character.digit(number.charAt(i), 10);
	int ar[]={j};
	for(int ten : ar){
	System.out.println(ten);
	}
}
}
}