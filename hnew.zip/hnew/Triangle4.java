class Triangle4
{
static int a;
static int b;
static int h;

Triangle4(int a,int b,int h)
{
 this.a=a;
this.b=b;
this.h=h;
	int area=(b*h)/2;
	System.out.println("area of triangle is :"+area);
	int peri=a+b+h;
	System.out.println("perimeter of triangle is :"+peri);
}

	public static void main(String... args){
	Triangle4 t4=new Triangle4(3,4,5);
	}
}