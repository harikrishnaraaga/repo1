class Student
{
 static String name;
 static Integer roll_no;
 	public static void main(String... args){
	Student s= new Student();
	s.name="John";
	s.roll_no=2;
	System.out.println("Name is :"+name);
	System.out.println("Roll_no is :"+roll_no);	
}
}