class Triangle3
{
static int a=3;
static int b=4;
static int h=5;
	public static void main(String... args){
	int area=(b*h)/2;
	System.out.println("area of traingle is :"+area);
	int peri=a+b+h;
	System.out.println("perimeter of traingle is :"+peri);
	}
}