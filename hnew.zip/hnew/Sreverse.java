import java.util.*;
class Sreverse
{
	public static void main(String[] args)
	{
		Scanner src=new Scanner(System.in);
		System.out.println("Enter String");
		String sr=src.nextLine();
		String rev="";
		for(int i=sr.length()-1;i>=0;i--)
		{
			rev=rev+sr.charAt(i);
		}
		System.out.println("Reversed string is "+rev);
	}

}