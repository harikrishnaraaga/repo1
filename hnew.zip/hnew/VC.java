public class VC {

    public static void main(String[] ar) {

String str=ar[0];
for(int i=0;i<ar.length;i++)
{
        switch (str) {
            case "a":
            case "e":
            case "i":
            case "o":
            case "u":
                System.out.println(str + " is vowel");
                break;
            default:
                System.out.println(str + " is consonant");
	break;
        }
}
    }
}