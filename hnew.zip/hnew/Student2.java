class Student2
{
static Integer roll_no1;
static Integer phone_no1;
static String address1;

static Integer roll_no2;
static Integer phone_no2;
static String address2;

	public static void main(String... args)
	{
	Student2 Sam=new Student2();
	Sam.roll_no1=1;
	Sam.phone_no1=7823456;
	Sam.address1="Bangalore";
	
	Student2 John=new Student2();
	John.roll_no2=2;
	John.phone_no2=463123;
	John.address2="Punjab";
	
	System.out.println("Sam roll_no is :"+Sam.roll_no1);
	System.out.println("Sam phone is :"+Sam.phone_no1);
	System.out.println("Sam address is :"+Sam.address1);

	System.out.println("John roll_no is :"+John.roll_no2);
	System.out.println("John Phone is :"+John.phone_no2);
	System.out.println("John address is :"+John.address2);
	}
}